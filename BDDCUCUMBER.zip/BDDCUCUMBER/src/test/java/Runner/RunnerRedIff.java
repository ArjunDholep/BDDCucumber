package Runner;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = {"src\\test\\resources\\Features\\login.feature"}, glue = {
		"stepdefinition"}, tags = "@SC2", plugin= {"pretty",
				"html:src\\test\\resources\\Reports\\cucumber2-reports.html",
				"json:src\\test\\resources\\Reports\\json1-reports.json",
				"junit:src\\test\\esources\\Reports\\junit1-reports.xml"
})

public class RunnerRedIff extends AbstractTestNGCucumberTests {

}
