package stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utility.Base1;

public class Functional {
	
	public static Base1 base;
	Page1 page = new Page1();
	

@Given("I navigate to website page")
public void i_navigate_to_website_page() {
   base.driver.get("https://www.rediff.com/");
   System.out.println("Navigated to the website page");
   
}

@When("I clicked create account link")
public void i_clicked_create_account_link() {
   page.signIn();
   System.out.println("clicked on create account link");
}

@When("I entered the details")
public void i_entered_the_details() {
   page.enterDetails();
   System.out.println("Entered the required details in the field");
}

@Then("I clicked the create account button")
public void i_clicked_the_create_account_button() {
    page.createAccount();
    System.out.println("Account Created");
}




}
