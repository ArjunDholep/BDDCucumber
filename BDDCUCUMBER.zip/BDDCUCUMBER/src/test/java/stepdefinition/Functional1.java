package stepdefinition;

import io.cucumber.java.en.Given;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utility.Base1;

public class Functional1 extends Base1 {
	public static Base1 base;
	Page2 page = new Page2();
	
	

@Given("I navigate to login page")
public void i_navigate_to_login_page() {
    // Write code here that turns the phrase above into concrete actions
	base.driver.get("https://www.rediff.com/");
	System.out.println("Navigated to the wensite page");
}

@When("I clicked signin link")
public void i_clicked_signin_link() {
    // Write code here that turns the phrase above into concrete actions
   page.signinLink();
   System.out.println("clicked the signin link");
}


@When("I entered {string} and {string}")
public void i_entered_and(String username, String password) {
	page.getLogin(username, password);
	System.out.println("username :"+ username);
	System.out.println("password :"+ password);
  
}

@Then("I clicked signin button")
public void i_clicked_signin_button() {
  page.Signin();
  System.out.println("Signed in");
}

@When("User enters invalid {string} and correct {string}")
public void user_enters_invalid_and_correct(String username, String password) {
  page.getLogin(username, password);
  System.out.println("username :"+ username);
  System.out.println("password :"+ password);
}

@When("User enters correct {string} and invalid {string}")
public void user_enters_correct_and_invalid(String username, String password) {
	 page.getLogin(username, password);
	  System.out.println("username :"+ username);
	  System.out.println("password :"+ password);
}




}
