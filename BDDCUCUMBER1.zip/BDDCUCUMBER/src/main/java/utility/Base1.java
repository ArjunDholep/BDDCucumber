package utility;

import org.openqa.selenium.WebDriver;

public class Base1 {
	public static WebDriver driver;

}
