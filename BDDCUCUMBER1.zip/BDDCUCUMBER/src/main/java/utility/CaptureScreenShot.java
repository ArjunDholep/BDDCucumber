package utility;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CaptureScreenShot {

	static WebDriver driver;
	public static void getErrorSchreenShot(WebDriver driver1) {
		driver = driver1;
		File x=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File y = new File("src\\test\\java\\Feb_26\\s1.png");
		try {
			FileUtils.copyFile(x, y);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void getErrorScreenshot2(WebDriver driver1) {
		driver = driver1;
		Date d=new Date();
		DateFormat df=new SimpleDateFormat("yyyy-MM-dd hh-mm-ss");
		String time=df.format(d);
		System.out.println(time);
		
		File x=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File y=new File("src\\main\\java\\screenshots\\screen"+time+".png");
		try {
			FileUtils.copyFile(x, y);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
