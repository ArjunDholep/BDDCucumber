package stepdefinition;

import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.Base1;

public class Page1 extends Base1 {
	public static Base1 base;
	//By signinLink = By.className("signinbtn");
	By accLink = By.linkText("Create a new account");
	By fulName = By.xpath("//div[@id='wrapper']/table[2]/tbody/tr[3]/td[3]/input[@type='text']");
	By rediffId = By.xpath("//td[@valign='bottom']/input[@type='text']");
	By CheckAvailability = By.className("btn_checkavail");
	By password = By.id("newpasswd");
	By retypePwd = By.id("newpasswd1");
	By checkBox = By.className("nomargin");
	By securityQuestion = By.xpath("//div[@id='div_hintQS']/table[1]/tbody/tr[2]/td[3]/select");
	By answer = By.xpath("//div[@id='div_hintQS']/table[1]/tbody/tr[4]/td[3]/input");
	By motherName = By.xpath("//div[@id='div_hintQS']/table[1]/tbody/tr[6]/td[3]/input");
	By mobileNo = By.id("mobno");
	By dobDay = By.xpath("//tbody/tr[22]/td[3]/select[1]");
	By dobMonth = By.xpath("//tbody/tr[22]/td[3]/select[2]");
	By dobYear = By.xpath("//tbody/tr[22]/td[3]/select[3]");
	By gender = By.xpath("//input[@value='m']");
	By country = By.id("country");
	By city = By.xpath("//tbody/tr[1]/td[3]/select[1]");
	By captcha = By.className("captcha");
	By newAcc = By.id("Register");
	
	
	public void signIn() {
		base.driver.findElement(accLink).click();
	}
	
	public void accountCreation() {
		base.driver.findElement(accLink).click();
	}
	
	public void enterDetails() {
		Scanner sc = new Scanner(System.in);
		
		base.driver.findElement(fulName).sendKeys("Abhishek");
		base.driver.findElement(rediffId).sendKeys("abhishekdeshpande920");
		base.driver.findElement(CheckAvailability).click();
		base.driver.findElement(password).sendKeys("Abhi@12345");
		base.driver.findElement(retypePwd).sendKeys("Abhi@12345");
		base.driver.findElement(checkBox).click();
		
		WebElement sq = base.driver.findElement(securityQuestion);
		Select st = new Select(sq);
		st.selectByIndex(1);
		
		base.driver.findElement(answer).sendKeys("Sanskar");
		base.driver.findElement(motherName).sendKeys("Mangal");
		
		base.driver.findElement(mobileNo).sendKeys("9999999991");
		
		WebElement day = base.driver.findElement(dobDay);
		Select d = new Select(day);
		d.selectByIndex(20);
		
		WebElement month = base.driver.findElement(dobMonth);
		Select m = new Select(month);
		m.selectByIndex(9);
		
		WebElement year = base.driver.findElement(dobYear);
		Select y = new Select(year);
		y.selectByIndex(24);
		
		base.driver.findElement(gender).click();
		
		WebElement countrySelect = base.driver.findElement(country);
		Select cs = new Select(countrySelect);
		cs.selectByIndex(0);
		
		WebElement citySelect = base.driver.findElement(city);
		Select ct = new Select(citySelect);
		ct.selectByIndex(56);
		
		
		WebDriverWait wait = new WebDriverWait(base.driver, Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(captcha));
		
		System.out.println("Enter the captcha: ");
		base.driver.findElement(captcha).sendKeys(sc.nextLine());
		
		
		
		
		
		
		
	}
	
	public void createAccount() {
		base.driver.findElement(newAcc).click();
	}
	

}
