package stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.Base1;

public class Page2 extends Base1 {
	public static Base1 base;
	
	By signinlink = By.linkText("Sign in");
	By username = By.id("login1");
	By password = By.id("password");
	By clickSignin = By.className("signinBtn");
	
	public void signinLink() {
		base.driver.findElement(signinlink).click();
	}
	
	public void getLogin(String user , String pass)
	{
		WebElement unm = base.driver.findElement(username);
		unm.sendKeys(user);
		WebElement pwd = base.driver.findElement(password);
		pwd.sendKeys(pass);
	}
	
	public void Signin() {
		base.driver.findElement(clickSignin).click();
	}


}
