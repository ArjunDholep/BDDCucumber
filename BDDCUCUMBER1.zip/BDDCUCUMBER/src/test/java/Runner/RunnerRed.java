package Runner;

import org.testng.annotations.Listeners;

import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features= {"src\\test\\resources\\Features\\accountsignin.feature"}, glue= {
		"stepdefinition"},
		plugin = {"pretty", "html:src\\test\\resources\\Reports\\cucumber-reports.html",
				"json:src\\test\\resources\\Reports\\json-reports.json",
				"junit:src\\test\\resources\\Reports\\junit-reports.xml",
				//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
 //  },
  //  monochrome = true
})
@Listeners({ExtentITestListenerClassAdapter.class})
public class RunnerRed extends AbstractTestNGCucumberTests {

}
